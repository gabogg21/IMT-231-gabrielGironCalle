// {} #
// \n*
#include <stdio.h>
int main(void){

    int num1 = 0;
    printf("Ingrese un numero entero: \n");
    scanf("%d",&num1);

    if(num1 > 0){
        printf("El numero es positivo: %d \n", num1);
    }
    if (num1 < 0){
        printf("El numero es negativo: %d \n", num1);
    }
    if (num1 ==0){
        printf("El numero es cero: %d \n", num1);
    }
            
            
            
        
     
              
} 