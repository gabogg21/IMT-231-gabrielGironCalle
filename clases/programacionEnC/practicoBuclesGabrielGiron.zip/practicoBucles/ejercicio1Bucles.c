#include <stdio.h>
int main(void){
    int N=0;
    printf("Ingrese un numero:\n ");
    scanf("%d", &N);
    printf("La secuencia es:\n");

    for (int i=1; i<=N;i++){
        printf("%d\n", i);

    }
    return 0;
    
   
} 
