#ifndef FUNCIONES_H
#define FUNCIONES_H
//

int esPrimo(int numeroPrimo);

int Factorial(int limite);

int contarDigitosPares(int digito1);

int contarDigitosImpares(int digito2);
#endif